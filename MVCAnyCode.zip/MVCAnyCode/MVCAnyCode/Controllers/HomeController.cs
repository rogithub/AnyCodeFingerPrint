﻿using DPUruNet;
using DPXUru;
using Microsoft.AspNetCore.Mvc;
using MVCAnyCode.Models;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Imaging;
using System.Runtime.InteropServices;
using System.Text;

namespace MVCAnyCode.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }

        private DataResult<Fmd> ExtractFmdfromBmp(Bitmap img, List<Fmd> preEnrollmentFmd)
        {
            byte[] imageByte = ExtractByteArray(img);
            int i = 0;
            //height, width and resolution must be same as those of image in ExtractByteArray
           DataResult<Fmd> fmd = DPUruNet.FeatureExtraction.CreateFmdFromRaw(imageByte, 0, 1, img.Width, img.Height, 512, Constants.Formats.Fmd.ISO);
            //DataResult<Fmd> fmd = DPUruNet.FeatureExtraction.CreateFmdFromRaw(imageByte, 0, 1, 504, 648, 1000, Constants.Formats.Fmd.DP_PRE_REGISTRATION);
            if (fmd.ResultCode == Constants.ResultCode.DP_SUCCESS)
            {
                while (i < 1)
                {
                    preEnrollmentFmd.Add(fmd.Data);
                    i++;
                }

                return fmd;
                //var enrolledFmd = DPUruNet.Enrollment.CreateEnrollmentFmd(Constants.Formats.Fmd.DP_REGISTRATION, preEnrollmentFmd);
                //if (enrolledFmd.ResultCode != Constants.ResultCode.DP_SUCCESS)
                //{
                //    throw new Exception("fallando"); 
                //}
                //return enrolledFmd;
            }
            else
                throw new Exception("fallando");

            
        }

        private static byte[] ExtractByteArray(Bitmap img)
        {
            byte[] rawData = null;
            byte[] bitData = null;
            //ToDo: CreateFmdFromRaw only works on 8bpp bytearrays. As such if we have an image with 24bpp then average every 3 values in Bitmapdata and assign it to bitdata
            if (img.PixelFormat == PixelFormat.Format8bppIndexed)
            {

                //Lock the bitmap's bits
                BitmapData bitmapdata = img.LockBits(new System.Drawing.Rectangle(0, 0, img.Width, img.Height), System.Drawing.Imaging.ImageLockMode.ReadWrite, img.PixelFormat);
                //Declare an array to hold the bytes of bitmap
                byte[] imgData = new byte[bitmapdata.Stride * bitmapdata.Height]; //stride=360, height 392

                //Copy bitmapdata into array
                Marshal.Copy(bitmapdata.Scan0, imgData, 0, imgData.Length);//imgData.length =141120

                bitData = new byte[bitmapdata.Width * bitmapdata.Height];//ditmapdata.width =357, height = 392

                for (int y = 0; y < bitmapdata.Height; y++)
                {
                    for (int x = 0; x < bitmapdata.Width; x++)
                    {
                        bitData[bitmapdata.Width * y + x] = imgData[y * bitmapdata.Stride + x];
                    }
                }

                rawData = new byte[bitData.Length];

                for (int i = 0; i < bitData.Length; i++)
                {
                    int avg = (img.Palette.Entries[bitData[i]].R + img.Palette.Entries[bitData[i]].G + img.Palette.Entries[bitData[i]].B) / 3;
                    rawData[i] = (byte)avg;
                }
            }

            else
            {
                bitData = new byte[img.Width * img.Height];//ditmapdata.width =357, height = 392, bitdata.length=139944
                for (int y = 0; y < img.Height; y++)
                {
                    for (int x = 0; x < img.Width; x++)
                    {
                        Color pixel = img.GetPixel(x, y);
                        bitData[img.Width * y + x] = (byte)((Convert.ToInt32(pixel.R) + Convert.ToInt32(pixel.G) + Convert.ToInt32(pixel.B)) / 3);
                    }
                }

            }

            return bitData;
        }



        [HttpPost]
        public IActionResult Sample()
        {
            //IdentifyResult i = new IdentifyResult(Constants.ResultCode.DP_FAILURE, null);
            CompareResult i = new CompareResult(Constants.ResultCode.DP_FAILURE, 0);
            if (Request.ContentLength > 0)
            {
                Bitmap b0 = new Bitmap("c:\\huell.png");//
                Bitmap b1 = new Bitmap(Request.Body);//("c:\\huell.png");//

                //b.Save("c:\\huell.png", ImageFormat.Png);

                var preEnrollmentFmd = new List<Fmd>();

                var x1 = ExtractFmdfromBmp(b0, preEnrollmentFmd);
                var x2 = ExtractFmdfromBmp(b1, preEnrollmentFmd);

                //i = Comparison.Identify(x1.Data, 0, preEnrollmentFmd, 100, 5);
                i = Comparison.Compare(x1.Data, 0, x2.Data, 0);
            }

            return Json(i);
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}