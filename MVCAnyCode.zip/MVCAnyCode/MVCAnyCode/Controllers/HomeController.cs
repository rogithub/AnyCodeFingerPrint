﻿using DPUruNet;
using DPXUru;
using Microsoft.AspNetCore.Mvc;
using MVCAnyCode.Models;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Imaging;
using System.Runtime.InteropServices;
using System.Text;

namespace MVCAnyCode.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }

        private DataResult<Fmd> ExtractFmdfromBmp(Bitmap img)
        {
            byte[] imageByte = ExtractByteArray(img);
            //height, width and resolution must be same as those of image in ExtractByteArray
           DataResult<Fmd> fmd = DPUruNet.FeatureExtraction.CreateFmdFromRaw(imageByte, 0, 1, img.Width, img.Height, 512, Constants.Formats.Fmd.ISO);
            if (fmd.ResultCode == Constants.ResultCode.DP_SUCCESS)            
                return fmd;
                           
                throw new Exception("fallando");
        }

        private byte[] ExtractByteArray(Image img)
        {
            return (byte[])System.ComponentModel.TypeDescriptor.GetConverter(img)
                .ConvertTo(img, typeof(byte[]));
        }



        [HttpPost]
        public IActionResult Sample()
        {
            //IdentifyResult i = new IdentifyResult(Constants.ResultCode.DP_FAILURE, null);
            CompareResult i = new CompareResult(Constants.ResultCode.DP_FAILURE, 0);
            if (Request.ContentLength > 0)
            {
                Bitmap b0 = new Bitmap("c:\\huella.png");//
                Bitmap b1 = new Bitmap(Request.Body);//("c:\\huell.png");//

                //b.Save("c:\\huella.png", ImageFormat.Png);

               
                var x1 = ExtractFmdfromBmp(b0);
                var x2 = ExtractFmdfromBmp(b1);

                //i = Comparison.Identify(x1.Data, 0, preEnrollmentFmd, 100, 5);
                i = Comparison.Compare(x1.Data, 0, x2.Data, 0);
            }

            return Json(i);
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}