(self["webpackChunkanycodefingerprint"] = self["webpackChunkanycodefingerprint"] || []).push([[712],{

/***/ 584:
/***/ (function(__unused_webpack_module, exports) {

(function (global, factory) {
     true ? factory(exports) :
    0;
}(this, function (exports) { 'use strict';

    /**
     * Provides a way to construct sanitized URLs from a base URL, a path and a query object
     */
    var Url = /** @class */ (function () {
        /** Constructs an URL object from a base URL, a path and a query object.
         * @param base - base URL, e.g. `https://contoso.com`
         * @param path - optional path, e.g. `api/v1/user`
         * @param query - optional set of query parameters, e.g. `{ name: "john", type: "5" }`
         * @remarks
         * The URL is built by concatenation of a base URL with sanitized path and query object,
         * adding all needed delimiters. Example:
         * @example
         * ```
         * const url = new Url("https://contoso.com", "api/v1/user", { name: "john", type: "5" });
         * console.log(url.href);
         * > https://contoso.com/api/v1/user?name=john&type=5
         * ```
         */
        function Url(base, path, query) {
            this.href = Url.create(base, path, query);
        }
        /** Builds a sanitized URL query from an JS object.
         * @returns A hyperlink reference.
         */
        Url.getSanitizedQuery = function (query) {
            return Object
                .keys(query)
                .map(function (key) { return [key, query[key]]
                .map(encodeURIComponent)
                .join("="); })
                .join("&");
        };
        /** Constructs an URL string from a base URL, a path and a query object.
         * @param base - base URL, e.g. `https://contoso.com`
         * @param path - optional path, e.g. `api/v1/user`
         * @param query - optional set of query parameters, e.g. `{ name: "john", type: "5" }`
         * @remarks
         * The URL is built by concatenation of a base URL with sanitized path and query object,
         * adding all needed delimiters.
         * @example
         * ```typescript
         * const href = Url.create("https://contoso.com", "api/v1/user", { name: "john", type: "5" });
         * console.log(href);
         * ```
         * `> https://contoso.com/api/v1/user?name=john&type=5`
         */
        Url.create = function (base, path, query) {
            return base
                + (path ? "/" + encodeURI(path) : "")
                + (query ? "?" + Url.getSanitizedQuery(query) : "");
        };
        return Url;
    }());

    /**
     * Biometric factors.
     */
    (function (BioFactor) {
        BioFactor[BioFactor["Multiple"] = 1] = "Multiple";
        BioFactor[BioFactor["FacialFeatures"] = 2] = "FacialFeatures";
        BioFactor[BioFactor["Voice"] = 4] = "Voice";
        BioFactor[BioFactor["Fingerprint"] = 8] = "Fingerprint";
        BioFactor[BioFactor["Iris"] = 16] = "Iris";
        BioFactor[BioFactor["Retina"] = 32] = "Retina";
        BioFactor[BioFactor["HandGeometry"] = 64] = "HandGeometry";
        BioFactor[BioFactor["SignatureDynamics"] = 128] = "SignatureDynamics";
        BioFactor[BioFactor["KeystrokeDynamics"] = 256] = "KeystrokeDynamics";
        BioFactor[BioFactor["LipMovement"] = 512] = "LipMovement";
        BioFactor[BioFactor["ThermalFaceImage"] = 1024] = "ThermalFaceImage";
        BioFactor[BioFactor["ThermalHandImage"] = 2048] = "ThermalHandImage";
        BioFactor[BioFactor["Gait"] = 4096] = "Gait";
    })(exports.BioFactor || (exports.BioFactor = {}));
    (function (BioSampleFormatOwner) {
        BioSampleFormatOwner[BioSampleFormatOwner["None"] = 0] = "None";
        /** Neurotechnologija (fingerprints). */
        BioSampleFormatOwner[BioSampleFormatOwner["Neurotechnologija"] = 49] = "Neurotechnologija";
        /** DigitalPersona (fingerprints) */
        BioSampleFormatOwner[BioSampleFormatOwner["DigitalPersona"] = 51] = "DigitalPersona";
        /** Cognitec (face) */
        BioSampleFormatOwner[BioSampleFormatOwner["Cognitec"] = 99] = "Cognitec";
        /** Innovatrics (face) */
        BioSampleFormatOwner[BioSampleFormatOwner["Innovatrics"] = 53] = "Innovatrics";
    })(exports.BioSampleFormatOwner || (exports.BioSampleFormatOwner = {}));
    /**
     * Biometric sample format info.
     */
    var BioSampleFormat = /** @class */ (function () {
        function BioSampleFormat(FormatOwner, FormatID) {
            this.FormatOwner = FormatOwner;
            this.FormatID = FormatID;
        }
        return BioSampleFormat;
    }());
    (function (BioSampleType) {
        BioSampleType[BioSampleType["Raw"] = 1] = "Raw";
        BioSampleType[BioSampleType["Intermediate"] = 2] = "Intermediate";
        BioSampleType[BioSampleType["Processed"] = 4] = "Processed";
        BioSampleType[BioSampleType["RawWSQCompressed"] = 8] = "RawWSQCompressed";
        BioSampleType[BioSampleType["Encrypted"] = 16] = "Encrypted";
        BioSampleType[BioSampleType["Signed"] = 32] = "Signed";
    })(exports.BioSampleType || (exports.BioSampleType = {}));
    (function (BioSamplePurpose) {
        BioSamplePurpose[BioSamplePurpose["Any"] = 0] = "Any";
        BioSamplePurpose[BioSamplePurpose["Verify"] = 1] = "Verify";
        BioSamplePurpose[BioSamplePurpose["Identify"] = 2] = "Identify";
        BioSamplePurpose[BioSamplePurpose["Enroll"] = 3] = "Enroll";
        BioSamplePurpose[BioSamplePurpose["EnrollForVerificationOnly"] = 4] = "EnrollForVerificationOnly";
        BioSamplePurpose[BioSamplePurpose["EnrollForIdentificationOnly"] = 5] = "EnrollForIdentificationOnly";
        BioSamplePurpose[BioSamplePurpose["Audit"] = 6] = "Audit";
    })(exports.BioSamplePurpose || (exports.BioSamplePurpose = {}));
    (function (BioSampleEncryption) {
        BioSampleEncryption[BioSampleEncryption["None"] = 0] = "None";
        BioSampleEncryption[BioSampleEncryption["XTEA"] = 1] = "XTEA";
    })(exports.BioSampleEncryption || (exports.BioSampleEncryption = {}));
    /**
     * Contains meta-information about biometric sample data.
     */
    var BioSampleHeader = /** @class */ (function () {
        function BioSampleHeader(
        /** Biometric factor. Must be set to 8 for fingerprint. */
        Factor, 
        /** Format owner (vendor) information. */
        Format, 
        /** Biometric sample representation type. */
        Type, 
        /** Purpose of the biometric sample. */
        Purpose, 
        /** Quality of biometric sample. If we don't support quality it should be set to -1.  */
        Quality, 
        /** Encryption of biometric sample. */
        Encryption) {
            this.Factor = Factor;
            this.Format = Format;
            this.Type = Type;
            this.Purpose = Purpose;
            this.Quality = Quality;
            this.Encryption = Encryption;
        }
        return BioSampleHeader;
    }());
    /**
     * A biometric sample.
     */
    var BioSample = /** @class */ (function () {
        function BioSample(
        /** Biometric sample header. */
        Header, 
        /** Base64url encoded biometric sample data */
        Data) {
            this.Header = Header;
            this.Data = Data;
            /** A version info. */
            this.Version = 1;
        }
        return BioSample;
    }());

    /*! *****************************************************************************
    Copyright (c) Microsoft Corporation. All rights reserved.
    Licensed under the Apache License, Version 2.0 (the "License"); you may not use
    this file except in compliance with the License. You may obtain a copy of the
    License at http://www.apache.org/licenses/LICENSE-2.0

    THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
    KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION ANY IMPLIED
    WARRANTIES OR CONDITIONS OF TITLE, FITNESS FOR A PARTICULAR PURPOSE,
    MERCHANTABLITY OR NON-INFRINGEMENT.

    See the Apache Version 2.0 License for specific language governing permissions
    and limitations under the License.
    ***************************************************************************** */

    var __assign = function() {
        __assign = Object.assign || function __assign(t) {
            for (var s, i = 1, n = arguments.length; i < n; i++) {
                s = arguments[i];
                for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
            }
            return t;
        };
        return __assign.apply(this, arguments);
    };

    function __read(o, n) {
        var m = typeof Symbol === "function" && o[Symbol.iterator];
        if (!m) return o;
        var i = m.call(o), r, ar = [], e;
        try {
            while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
        }
        catch (error) { e = { error: error }; }
        finally {
            try {
                if (r && !r.done && (m = i["return"])) m.call(i);
            }
            finally { if (e) throw e.error; }
        }
        return ar;
    }

    function __spread() {
        for (var ar = [], i = 0; i < arguments.length; i++)
            ar = ar.concat(__read(arguments[i]));
        return ar;
    }

    // tslint:disable: ban-types
    /**
     * Set of converters to UTF16.
     */
    var Utf16 = /** @class */ (function () {
        function Utf16() {
        }
        /** Converts a UTF8 string to a UTF16 string. */
        Utf16.fromUtf8 = function (s) {
            return decodeURIComponent(escape(Utf8.noBom(s)));
        };
        /** Decodes a Base64-encoded string to a UTF16 string. */
        Utf16.fromBase64 = function (s) {
            return Utf16.fromUtf8(Utf8.fromBase64(s));
        };
        /** Decodes a Base64url-encoded string to a UTF16 string. */
        Utf16.fromBase64Url = function (s) {
            return Utf16.fromUtf8(Utf8.fromBase64Url(s));
        };
        /** Appends Byte-Order-Mark (BOM) to the UTF16 string. */
        Utf16.withBom = function (s) { return "\uFEFF" + s; };
        /** Strips a Byte-Order-Mark (BOM) from the UTF16 string. */
        Utf16.noBom = function (s) { return s.replace(/^\uFEFF/, ""); };
        return Utf16;
    }());
    /**
     * Set of converters to UTF8.
     */
    var Utf8 = /** @class */ (function () {
        function Utf8() {
        }
        /** Converts a UTF16 string to a UTF16 string. */
        Utf8.fromUtf16 = function (s) {
            return unescape(encodeURIComponent(Utf16.noBom(s)));
        };
        /** Decodes a Base64-encoded string to a UTF8 string. */
        Utf8.fromBase64 = function (s) {
            return atob(s);
        };
        /** Decodes a Base64url-encoded string to a UTF8 string. */
        Utf8.fromBase64Url = function (s) {
            return Utf8.fromBase64(Base64.fromBase64Url(s));
        };
        /** Converts a byte array to a UTF16 string. */
        Utf8.fromBytes = function (bytes) {
            return String.fromCharCode.apply(String, __spread(bytes));
        };
        /** Appends Byte-Order-Mark (BOM) to the UTF8 string. */
        Utf8.withBom = function (s) { return "\xEF\xBB\xBF" + s; };
        /** Strips a Byte-Order-Mark (BOM) from the UTF8 string. */
        Utf8.noBom = function (s) { return s.replace(/^\xEF\xBB\xBF/, ""); };
        return Utf8;
    }());
    /**
     * Set of converters to Base64.
     */
    var Base64 = /** @class */ (function () {
        function Base64() {
        }
        /** Encodes a UTF8 string to a Base64-encoded string. */
        Base64.fromUtf8 = function (s) {
            return btoa(s);
        };
        /** Encodes a UTF16 string to a Base64-encoded string.  */
        Base64.fromUtf16 = function (s) {
            return Base64.fromUtf8(Utf8.fromUtf16(s));
        };
        /** Converts a Base64url-encoded string to a Base64-encoded string. */
        Base64.fromBase64Url = function (s) {
            return ((s.length % 4 === 2) ? s + "==" :
                (s.length % 4 === 3) ? s + "=" : s)
                .replace(/-/g, "+")
                .replace(/_/g, "/");
        };
        /** Converts a byte array to a Base64-encoded string. */
        Base64.fromBytes = function (bytes) {
            return Base64.fromUtf8(Utf8.fromBytes(bytes));
        };
        /** Encodes a plain JSON object or a string to a Base64-encoded string. */
        Base64.fromJSON = function (obj) {
            return Base64.fromUtf16(JSON.stringify(obj));
        };
        return Base64;
    }());
    /**
     * Set of converters to Base64Url.
     */
    var Base64Url = /** @class */ (function () {
        function Base64Url() {
        }
        /** Converts a Base64-encoded string to a Base64url-encoded string. */
        Base64Url.fromBase64 = function (s) {
            return s.replace(/\=/g, "").replace(/\+/g, "-").replace(/\//g, "_");
        };
        /** Converts a UTF8 string to a Base64url-encoded string. */
        Base64Url.fromUtf8 = function (s) {
            return Base64Url.fromBase64(Base64.fromUtf8(s));
        };
        /** Converts a UTF16 string to a Base64url-encoded string. */
        Base64Url.fromUtf16 = function (s) {
            return Base64Url.fromBase64(Base64.fromUtf16(s));
        };
        /** Converts a byte array to a Base64url-encoded string. */
        Base64Url.fromBytes = function (bytes) {
            return Base64Url.fromUtf8(Utf8.fromBytes(bytes));
        };
        /** Encodes a plain JSON object or a string to a Base64url-encoded string. */
        Base64Url.fromJSON = function (obj) {
            return Base64Url.fromUtf16(JSON.stringify(obj));
        };
        return Base64Url;
    }());
    /**
     * Set of converters to Base32.
     */
    var Base32 = /** @class */ (function () {
        function Base32() {
        }
        /** Converts a byte array to a Base32-encoded string. */
        Base32.fromBytes = function (bytes) {
            var digits = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";
            var v1 = 0, v2 = 0, v3 = 0, v4 = 0, v5 = 0, str = '', l = bytes.length, i = 0;
            var count = Math.floor(l / 5) * 5;
            while (i < count) {
                v1 = bytes[i++];
                v2 = bytes[i++];
                v3 = bytes[i++];
                v4 = bytes[i++];
                v5 = bytes[i++];
                str += digits[v1 >>> 3]
                    + digits[(v1 << 2 | v2 >>> 6) & 31]
                    + digits[(v2 >>> 1) & 31]
                    + digits[(v2 << 4 | v3 >>> 4) & 31]
                    + digits[(v3 << 1 | v4 >>> 7) & 31]
                    + digits[(v4 >>> 2) & 31]
                    + digits[(v4 << 3 | v5 >>> 5) & 31]
                    + digits[v5 & 31];
            }
            // remain char
            var remain = l - count;
            if (remain === 0)
                return str;
            switch (remain) {
                // @ts-ignore no-switch-case-fall-through
                case 4: v4 = bytes[--l];
                // @ts-ignore no-switch-case-fall-through
                case 3: v3 = bytes[--l];
                // @ts-ignore no-switch-case-fall-through
                case 2: v2 = bytes[--l];
                // @ts-ignore no-switch-case-fall-through
                case 1: v1 = bytes[--l];
            }
            str += digits[v1 >>> 3];
            switch (remain) {
                case 1: return str
                    + digits[(v1 << 2) & 31]
                    + '======';
                case 2: return str
                    + digits[(v1 << 2 | v2 >>> 6) & 31]
                    + digits[(v2 >>> 1) & 31]
                    + digits[(v2 << 4) & 31]
                    + '====';
                case 3: return str
                    + digits[(v1 << 2 | v2 >>> 6) & 31]
                    + digits[(v2 >>> 1) & 31]
                    + digits[(v2 << 4 | v3 >>> 4) & 31]
                    + digits[(v3 << 1) & 31]
                    + '===';
                case 4: return str
                    + digits[(v1 << 2 | v2 >>> 6) & 31]
                    + digits[(v2 >>> 1) & 31]
                    + digits[(v2 << 4 | v3 >>> 4) & 31]
                    + digits[(v3 << 1 | v4 >>> 7) & 31]
                    + digits[(v4 >>> 2) & 31]
                    + digits[(v4 << 3) & 31]
                    + '=';
            }
            return str;
        };
        return Base32;
    }());
    // export class Hex
    // {
    //     public static encode = (s: string): HexString =>
    //         s.split("").map(cp => ('000' + cp.charCodeAt(0).toString(16)).slice(-4)).join('')
    //     public static decode = (s: HexString): string =>
    //         s.replace(/(..)/g, '%$1'))
    // }

    /** Enumerates supported username formats. */
    (function (UserNameType) {
        /** A name not associated with any Windows account, to be used for local databases only.  */
        UserNameType[UserNameType["Unknown"] = 0] = "Unknown";
        /** NetBIOS domain name, for example, “THE_COMPANY”. */
        UserNameType[UserNameType["NetBIOSDomain"] = 1] = "NetBIOSDomain";
        /** A DNS domain name, for example, “thecompany.com”. */
        UserNameType[UserNameType["DNSDomain"] = 2] = "DNSDomain";
        /** A MS Windows account name, e.g “the_company\jdoe” (domain\user) or "the_company\" (domain only). */
        UserNameType[UserNameType["SAM"] = 3] = "SAM";
        /** The account name format used in Microsoft(r) Windows NT(r) 4.0, for example, “jdoe”.  */
        UserNameType[UserNameType["Simple"] = 4] = "Simple";
        /** A GUID string, for example, “4fa050f0-f561-11cf-bdd9-00aa003a77b6”.  */
        UserNameType[UserNameType["UID"] = 5] = "UID";
        /** A user principal name, for example, “jdoe@thecompany.com”.  */
        UserNameType[UserNameType["UPN"] = 6] = "UPN";
        /** A friendly display name, for example, “John Doe”. */
        UserNameType[UserNameType["Display"] = 7] = "Display";
        /** A user SID string, for example, “S-1-5-21-1004”. */
        UserNameType[UserNameType["SID"] = 8] = "SID";
        /** A user name associated with DigitalPersona identity database (formerly known as "Altus user"). */
        UserNameType[UserNameType["DP"] = 9] = "DP";
    })(exports.UserNameType || (exports.UserNameType = {}));

    /**
     * Represents a user's identity using a user's name name and a type of the name.
     * This class is typially used to pass a user name during authentication.
     */
    var User = /** @class */ (function () {
        /** Constructs the object using a username and a user type.
         * @param name - user name. No name transformation/canonicalization is performed.
         * @param type - an optional type of the user. If not provided, he type is deduced automatically.
         * @remarks
         * If no `type` parameter is provided, the username format is analyzes and automatic type is assigned.
         * For example:
         * * "user\@comtoso.com" name will be parsed as a {@link UserNameType.UPN | User Principal Name (UPN)},
         * * "Domain\\UserX" name will be parsed as a {@link UserNameType.SAM | Security Account Manager (SAM)} name,
         * * "6de5b5ed-85fc-4298-a18b-dac7d5a18369" will be parsed as a {@link UserNameType.UID | Unique Identifier (UID)} name,
         * * "UserX" name will be parsed as a {@link UserNameType.DP | DigitalPersona name} (used in LDS)
         * You may provide a `type` parameter if you want to enforce a specific name type.
         */
        function User(name, type) {
            var reGUID = /^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$/;
            this.name = name || "";
            this.type = type || ((this.name.length === 0) ? exports.UserNameType.Unknown :
                (this.name === "*") ? exports.UserNameType.Unknown :
                    (this.name.indexOf('@') !== -1) ? exports.UserNameType.UPN :
                        (this.name.indexOf('\\') !== -1) ? exports.UserNameType.SAM :
                            reGUID.test(this.name) ? exports.UserNameType.UID
                                : exports.UserNameType.DP);
        }
        /** @returns `true` when the User object represents an anonymous user. */
        User.prototype.isAnonymous = function () {
            return !this.name || this.name.length === 0;
        };
        /** @returns `true` whrn the user object represents any user. */
        User.prototype.isEveryone = function () {
            return this.name === "*";
        };
        /** Creates a user object representing an anonymous user. */
        User.Anonymous = function () {
            return new User("", exports.UserNameType.Unknown);
        };
        /** Creates a user object representing every user. */
        User.Everyone = function () {
            return new User("*", exports.UserNameType.Unknown);
        };
        /** Creates a user object using claims in a JSON Web Token.
         * @param token - a JSON Web Token.
         * @param type - an optional username type to override automatic type detection and force a specific name format.
         * @returns a user object constructed from the `token` claims.
         * @remarks
         * The `token` should contain either {@link ClaimSet.sub |`sub`} or {@link ClaimSet.wan | `wan`} claim
         * to detect a user name. If no such claims are found, then {@link User.Anonymous | anonymous} user is returned.
         * The {@link ClaimSet.sub |`sub`} claim has a priority over the {@link ClaimSet.wan | `wan`} claim.
         * If `type` parameter is not defined, the name type is deduced automatically from the name string.
         * You may provide a `type` parameter if you want to enforce a specific name type.
         * See {@link User.constructor} for type deduction details.
         */
        User.fromJWT = function (token, type) {
            var claims = JWT.claims(token);
            var user = claims.sub && (claims.sub instanceof User) ? claims.sub :
                claims.wan ? new User(claims.wan, type) :
                    claims.sub ? new User(claims.sub, type || exports.UserNameType.DP) : User.Anonymous();
            return user;
        };
        return User;
    }());

    /** Represents a JSON Web Token Header. */
    var JWTHeader = /** @class */ (function () {
        /** Constructs a JWT header. */
        function JWTHeader(typ, alg, cty) {
            this.typ = typ;
            this.cty = cty;
            this.alg = alg;
        }
        return JWTHeader;
    }());
    /** Represents a JSON Web Token and gives access to the token's payload.
     * Note that this class does not allow to validate the token signature in the browser,
     * it must be done on a server side.
     */
    var JWT = /** @class */ (function () {
        function JWT() {
        }
        /** Extracts a claims set from the JSON Web Token.
         * @param jwt - a JSON Web Token string.
         * @returns a claims set.
         */
        JWT.claims = function (jwt) {
            var parts = jwt.split('.');
            var header = JSON.parse(Utf16.fromBase64Url(parts[0]));
            if (header.cty === "JWT") {
                // we have a nested JWT with encrypted payload (JWE).
                // Encrypted nested JWT may replicate some claims in the header to be publicly accessible.
                return __assign(__assign({}, header), new JWTHeader());
            }
            else {
                // unencrypted payload, use claims from the payload only
                var payload = JSON.parse(Utf16.fromBase64Url(parts[1]));
                // convert "subject" to a User type
                if (typeof (payload.sub) === "object") {
                    var _a = payload.sub, name_1 = _a.name, type = _a.type;
                    payload.sub = new User(name_1, type);
                }
                return payload;
            }
        };
        /** Validates the JSON Web Token and returns a collection of detected validation errors.
         * @param jwt - a JSON Web Token.
         * @returns an array of errors found, or `null` if the token is valid.
         * @remarks
         * Only client-side checks are performed, no signature validation.
         * The token's claims must satisfy following expression:
         * `iat <= nbf < now < exp`
         * where `iat` is time when the token was issued, `nbf` is a time when the token becomes valid,
         * `exp` is a token expiration time, `now` is current time.
         * Following errors may be returned:
         *
         *   * 'JWT.Error.IssueTimeLaterThanNotBefore' if `iat > nbf`,
         *   * 'JWT.Error.NotEffectiveYet' when `now < nbf`,
         *   * 'JWT.Error.Expired' when `now >= exp`.
         */
        JWT.errors = function (jwt) {
            var e = [];
            var claims = JWT.claims(jwt);
            var now = new Date().getTime() / 1000; // seconds since the epoch start
            // iat < nbf < now < exp
            if (claims.iat && claims.nbf && claims.iat > claims.nbf)
                e.push(new Error('JWT.Error.IssueTimeLaterThanNotBefore'));
            if (claims.nbf && claims.nbf > now)
                e.push(new Error('JWT.Error.NotEffectiveYet'));
            if (claims.exp && claims.exp <= now)
                e.push(new Error('JWT.Error.Expired'));
            return e.length > 0 ? e : null;
        };
        return JWT;
    }());

    /** Enumerate publicly registered and private DigitalPersona claim names. */
    (function (ClaimName) {
        // registered names
        ClaimName["TokensId"] = "jti";
        ClaimName["IssuerName"] = "iss";
        ClaimName["IssuedAt"] = "iat";
        ClaimName["Audience"] = "aud";
        ClaimName["NotBefore"] = "nbf";
        ClaimName["ExpiresAfter"] = "exp";
        ClaimName["SubjectName"] = "sub";
        // private DigitalPersona names
        ClaimName["IssuerDomain"] = "dom";
        ClaimName["SubjectUid"] = "uid";
        ClaimName["ADGuid"] = "ad_guid";
        ClaimName["CredentialsUsed"] = "crd";
        ClaimName["Group"] = "group";
        ClaimName["Role"] = "role";
        ClaimName["WindowsAccountName"] = "wan";
        ClaimName["T24Principal"] = "t24";
    })(exports.ClaimName || (exports.ClaimName = {}));

    /**
     * A structure wrapping a JSON Web Token to pass it to the DigitalPersona Web Components services.
     */
    var Ticket = /** @class */ (function () {
        /** Constructs a ticket object. */
        function Ticket(jwt) {
            this.jwt = jwt;
        }
        /** Creates a ticket with an emtpy token. Used as a placeholder when no token is needed. */
        Ticket.None = function () {
            return new Ticket("");
        };
        return Ticket;
    }());

    /**
     * Credential data.
     */
    var Credential = /** @class */ (function () {
        /** Constructs a credential. */
        function Credential(id, data, encode) {
            if (encode === void 0) { encode = true; }
            this.id = id;
            this.data = !data ? null
                : !encode ? JSON.stringify(data)
                    : Base64Url.fromUtf16(typeof (data) !== "string" ? JSON.stringify(data) : data);
        }
        /** Constructs an empty credential object. */
        Credential.None = function () {
            return new Credential("");
        };
        /** Constructs a credential object representing any credential. */
        Credential.Any = function () {
            return new Credential("*");
        };
        // true credentials
        Credential.Password = "D1A1F561-E14A-4699-9138-2EB523E132CC";
        Credential.Fingerprints = "AC184A13-60AB-40E5-A514-E10F777EC2F9";
        Credential.Face = "85AEAA44-413B-4DC1-AF09-ADE15892730A";
        Credential.SmartCard = "D66CC98D-4153-4987-8EBE-FB46E848EA98";
        Credential.ContactlessCard = "F674862D-AC70-48CA-B73E-64A22F3BAC44";
        Credential.ProximityCard = "1F31360C-81C0-4EE0-9ACD-5A4400F66CC2";
        Credential.PIN = "8A6FCEC3-3C8A-40C2-8AC0-A039EC01BA05";
        Credential.SecurityQuestions = "B49E99C6-6C94-42DE-ACD7-FD6B415DF503";
        Credential.Bluetooth = "E750A180-577B-47F7-ACD9-F89A7E27FA49";
        Credential.OneTimePassword = "324C38BD-0B51-4E4D-BD75-200DA0C8177F";
        Credential.U2F = "5D5F73AF-BCE5-4161-9584-42A61AED0E48";
        Credential.IWA = "AE922666-9667-49BC-97DA-1EB0E1EF73D2";
        Credential.Email = "7845D71D-AB67-4EA7-913C-F81E75C3A087";
        Credential.Behavior = "193C41F6-5CF6-4525-84CC-223603DAC9AB";
        // pseudo-credentials
        Credential.Cards = "FCFA704C-144B-42DB-8DF3-13F5CD20C525"; // all card types
        return Credential;
    }());

    /**
     * Positions of fingers.
     */
    (function (FingerPosition) {
        FingerPosition[FingerPosition["Unknown"] = 0] = "Unknown";
        FingerPosition[FingerPosition["RightThumb"] = 1] = "RightThumb";
        FingerPosition[FingerPosition["RightIndex"] = 2] = "RightIndex";
        FingerPosition[FingerPosition["RightMiddle"] = 3] = "RightMiddle";
        FingerPosition[FingerPosition["RightRing"] = 4] = "RightRing";
        FingerPosition[FingerPosition["RightLittle"] = 5] = "RightLittle";
        FingerPosition[FingerPosition["LeftThumb"] = 6] = "LeftThumb";
        FingerPosition[FingerPosition["LeftIndex"] = 7] = "LeftIndex";
        FingerPosition[FingerPosition["LeftMiddle"] = 8] = "LeftMiddle";
        FingerPosition[FingerPosition["LeftRing"] = 9] = "LeftRing";
        FingerPosition[FingerPosition["LeftLittle"] = 10] = "LeftLittle";
    })(exports.FingerPosition || (exports.FingerPosition = {}));
    /** Finger enrollment data. */
    var Finger = /** @class */ (function () {
        function Finger(
        /** Finger position. */
        position) {
            this.position = position;
        }
        /** Creates the finger enrollment data from a plain JSON object. */
        Finger.fromJson = function (json) {
            var obj = json;
            return new Finger(obj.position);
        };
        return Finger;
    }());

    (function (FaceImageType) {
        FaceImageType[FaceImageType["Jpeg"] = 1] = "Jpeg";
    })(exports.FaceImageType || (exports.FaceImageType = {}));
    /**
     * Face image data.
     */
    var FaceImage = /** @class */ (function () {
        function FaceImage(
        /** Base64url-encoded image data. */
        ImageData, 
        /** Image format. */
        ImageType) {
            if (ImageType === void 0) { ImageType = exports.FaceImageType.Jpeg; }
            this.ImageData = ImageData;
            this.ImageType = ImageType;
            /** Version info. */
            this.Version = 1;
        }
        /** Extracts face image from a data URL. Only `data:image/jpeg;base64` is supported for now. */
        FaceImage.fromDataURL = function (image) {
            return new FaceImage(image.replace("data:image/jpeg;base64,", ""));
        };
        /** Extracts face image from a browser's canvas object.  */
        FaceImage.fromCanvas = function (canvas, quality) {
            if (quality === void 0) { quality = 1.0; }
            return FaceImage.fromDataURL(canvas.toDataURL("image/jpeg", quality));
        };
        /** Exports the face image data to a {@link BioSample} object. */
        FaceImage.prototype.toBioSample = function (format, purpose, sdkVersion) {
            if (format === void 0) { format = new BioSampleFormat(exports.BioSampleFormatOwner.None, 0); }
            if (purpose === void 0) { purpose = exports.BioSamplePurpose.Any; }
            return new BioSample(new BioSampleHeader(exports.BioFactor.FacialFeatures, format, exports.BioSampleType.Raw, purpose, -1, exports.BioSampleEncryption.None), Base64Url.fromJSON(this));
        };
        return FaceImage;
    }());

    /**
     * Type of a security question.
     */
    (function (QuestionType) {
        /** A security question from a standard predefined list of questions ({@link Question.number} <= 100). */
        QuestionType[QuestionType["Regular"] = 0] = "Regular";
        /** A user-defined security question ({@link Question.number} > 100). */
        QuestionType[QuestionType["Custom"] = 1] = "Custom";
    })(exports.QuestionType || (exports.QuestionType = {}));
    /**
     * Security question data.
     */
    var Question = /** @class */ (function () {
        /** Constructs a security question. */
        function Question(
        /** An index of a question in a question list. */
        number, 
        /** A question language ID. */
        lang_id, 
        /** A question sublanguage ID. */
        sublang_id, 
        /** A keyboard layout for the answer. */
        keyboard_layout, 
        /** A text of the security question (only when {@link Question.type} === {@link QuestionType.Custom}) */
        text) {
            this.number = number;
            this.lang_id = lang_id;
            this.sublang_id = sublang_id;
            this.keyboard_layout = keyboard_layout;
            this.text = text;
            /** Version info. */
            this.version = 1;
            this.type = number <= 100 ? exports.QuestionType.Regular : exports.QuestionType.Custom;
            if (this.type === exports.QuestionType.Custom && !text)
                throw new Error("Question text is required for custom questions");
        }
        /** Creates a security question from a plain JSON object. */
        Question.fromJson = function (json) {
            var obj = json;
            return new Question(obj.number, obj.lang_id, obj.sublang_id, obj.keyboard_layout, obj.text);
        };
        return Question;
    }());
    /**
     * An answer to a security question.
     */
    var Answer = /** @class */ (function () {
        /** Creates an answer to a security question. */
        function Answer(question, text) {
            this.text = text;
            this.number = (question instanceof Question) ? question.number : question;
        }
        return Answer;
    }());

    exports.Answer = Answer;
    exports.Base32 = Base32;
    exports.Base64 = Base64;
    exports.Base64Url = Base64Url;
    exports.BioSample = BioSample;
    exports.BioSampleFormat = BioSampleFormat;
    exports.BioSampleHeader = BioSampleHeader;
    exports.Credential = Credential;
    exports.FaceImage = FaceImage;
    exports.Finger = Finger;
    exports.JWT = JWT;
    exports.Question = Question;
    exports.Ticket = Ticket;
    exports.Url = Url;
    exports.User = User;
    exports.Utf16 = Utf16;
    exports.Utf8 = Utf8;

    Object.defineProperty(exports, '__esModule', { value: true });

}));
//# sourceMappingURL=index.umd.js.map


/***/ }),

/***/ 218:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

(function (global, factory) {
     true ? factory(exports, __webpack_require__(584), __webpack_require__(893)) :
    0;
}(this, function (exports, core) { 'use strict';

    /*! *****************************************************************************
    Copyright (c) Microsoft Corporation. All rights reserved.
    Licensed under the Apache License, Version 2.0 (the "License"); you may not use
    this file except in compliance with the License. You may obtain a copy of the
    License at http://www.apache.org/licenses/LICENSE-2.0

    THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
    KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION ANY IMPLIED
    WARRANTIES OR CONDITIONS OF TITLE, FITNESS FOR A PARTICULAR PURPOSE,
    MERCHANTABLITY OR NON-INFRINGEMENT.

    See the Apache Version 2.0 License for specific language governing permissions
    and limitations under the License.
    ***************************************************************************** */
    /* global Reflect, Promise */

    var extendStatics = function(d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };

    function __extends(d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    }

    /**
     * A base class for DigitalPersona events.
     */
    var Event = /** @class */ (function () {
        function Event(type) {
            this.type = type;
        }
        return Event;
    }());
    /**
     * An event signaling a problem with a device channel communication.
     */
    var CommunicationFailed = /** @class */ (function (_super) {
        __extends(CommunicationFailed, _super);
        function CommunicationFailed() {
            return _super.call(this, "CommunicationFailed") || this;
        }
        return CommunicationFailed;
    }(Event));

    /** A base class for device events.  */
    var DeviceEvent = /** @class */ (function (_super) {
        __extends(DeviceEvent, _super);
        /** Constructs a new event.
         * @param type - an event type
         * @param deviceId - a device ID.
         */
        function DeviceEvent(type, deviceId) {
            var _this = _super.call(this, type) || this;
            _this.deviceId = deviceId;
            return _this;
        }
        return DeviceEvent;
    }(Event));
    /** An event signaling that a device was connected. */
    var DeviceConnected = /** @class */ (function (_super) {
        __extends(DeviceConnected, _super);
        /** Constructs a new event.
         * @param deviceId - a device ID.
         */
        function DeviceConnected(deviceId) {
            return _super.call(this, "DeviceConnected", deviceId) || this;
        }
        return DeviceConnected;
    }(DeviceEvent));
    /** An event signaling that a device was disconnected. */
    var DeviceDisconnected = /** @class */ (function (_super) {
        __extends(DeviceDisconnected, _super);
        /** Constructs a new event.
         * @param deviceId - a device ID.
         */
        function DeviceDisconnected(deviceId) {
            return _super.call(this, "DeviceDisconnected", deviceId) || this;
        }
        return DeviceDisconnected;
    }(DeviceEvent));

    /** Enumerates supported card types. */
    (function (CardType) {
        /** A smartcard. */
        CardType[CardType["Contact"] = 1] = "Contact";
        /** A contactless card. */
        CardType[CardType["Contactless"] = 2] = "Contactless";
        /** A proximity card. */
        CardType[CardType["Proximity"] = 4] = "Proximity";
    })(exports.CardType || (exports.CardType = {}));
    (function (CardAttributes) {
        /** The card supports PIN code. */
        CardAttributes[CardAttributes["SupportsPIN"] = 1] = "SupportsPIN";
        /** The card supports UID. */
        CardAttributes[CardAttributes["SupportsUID"] = 2] = "SupportsUID";
        /** The card supports PKI. */
        CardAttributes[CardAttributes["IsPKI"] = 65536] = "IsPKI";
        /** The card supports PIV. */
        CardAttributes[CardAttributes["IsPIV"] = 131072] = "IsPIV";
        /** The card is read-only. */
        CardAttributes[CardAttributes["IsReadOnly"] = 2147483648] = "IsReadOnly";
    })(exports.CardAttributes || (exports.CardAttributes = {}));

    /**
     * An event signaling that a card was presented (inserted or touched) to a card reader.
     */
    var CardInserted = /** @class */ (function (_super) {
        __extends(CardInserted, _super);
        /** Contructs a new event object.
         * @param reader - a name of a card reader where the card was presented.
         * @param card - a name of a card presented.
         */
        function CardInserted(reader, card) {
            var _this = _super.call(this, "CardInserted", reader) || this;
            _this.cardId = card;
            return _this;
        }
        return CardInserted;
    }(DeviceEvent));
    /** An event signaling that a card was removed from a card reader. */
    var CardRemoved = /** @class */ (function (_super) {
        __extends(CardRemoved, _super);
        /** Contructs a new event object.
         * @param reader - a name of a card reader where the card was presented.
         * @param card - a name of a card presented.
         */
        function CardRemoved(reader, card) {
            var _this = _super.call(this, "CardRemoved", reader) || this;
            _this.cardId = card;
            return _this;
        }
        return CardRemoved;
    }(DeviceEvent));

    /**@internal
     *
     */
    var MultiCastEventSource = /** @class */ (function () {
        function MultiCastEventSource() {
            this.handlers = {};
        }
        MultiCastEventSource.prototype._on = function (event, handler) {
            this.handlers[event] = this.handlers[event] || [];
            this.handlers[event].push(handler);
            return handler;
        };
        MultiCastEventSource.prototype._off = function (event, handler) {
            if (event) {
                var hh = this.handlers[event];
                if (hh) {
                    if (handler)
                        this.handlers[event] = hh.filter(function (h) { return h !== handler; });
                    else
                        delete this.handlers[event];
                }
            }
            else
                this.handlers = {};
            return this;
        };
        MultiCastEventSource.prototype.emit = function (event) {
            var _this = this;
            if (!event)
                return;
            var eventName = event.type;
            var unicast = this["on" + eventName];
            if (unicast)
                this.invoke(unicast, event);
            var multicast = this.handlers[eventName];
            if (multicast)
                multicast.forEach(function (h) { return _this.invoke(h, event); });
        };
        MultiCastEventSource.prototype.invoke = function (handler, event) {
            try {
                handler(event);
            }
            catch (e) {
                console.error(e);
            }
        };
        return MultiCastEventSource;
    }());

    /**@internal
     *
     */
    var MessageType;
    (function (MessageType) {
        MessageType[MessageType["Response"] = 0] = "Response";
        MessageType[MessageType["Notification"] = 1] = "Notification";
    })(MessageType || (MessageType = {}));

    /**@internal
     *
     */
    var Channel = /** @class */ (function () {
        function Channel(channelName, options) {
            this.pending = [];
            this.webChannel = new WebSdk.WebChannelClient(channelName, options);
            this.webChannel.onConnectionSucceed = this.onConnectionSucceed.bind(this);
            this.webChannel.onConnectionFailed = this.onConnectionFailed.bind(this);
            this.webChannel.onDataReceivedTxt = this.onDataReceivedTxt.bind(this);
        }
        Channel.prototype.send = function (request, timeout) {
            var deferred = new Promise(function (resolve, reject) {
                request.resolve = resolve;
                request.reject = reject;
                if (timeout) {
                    request.timer = window.setTimeout(function () {
                        if (request.timer)
                            try {
                                request.reject(new Error("Timeout"));
                            }
                            catch (e) { }
                    }, timeout);
                }
            });
            this.pending.push(request);
            if (this.webChannel.isConnected())
                this.processRequestQueue();
            else
                this.webChannel.connect();
            return deferred;
        };
        Channel.prototype.onConnectionSucceed = function () {
            this.processRequestQueue();
        };
        Channel.prototype.onConnectionFailed = function () {
            this.pending.forEach(function (r) { return r.reject(new Error("Communication failure.")); });
            this.pending = [];
            if (this.onCommunicationError)
                try {
                    this.onCommunicationError();
                }
                catch (e) { }
        };
        Channel.prototype.onDataReceivedTxt = function (data) {
            var message = JSON.parse(core.Utf8.fromBase64Url(data));
            if (message.Type === MessageType.Response) {
                var response = JSON.parse(core.Utf8.fromBase64Url(message.Data || ""));
                var request = this.findRequest(response);
                if (request !== null) {
                    if (request.timer) {
                        window.clearTimeout(request.timer);
                        delete request.timer;
                    }
                    var hr = (response.Result >>> 0);
                    if (hr > 0x7FFFFFFF)
                        request.reject(new Error("0x" + hr.toString(16)));
                    else
                        request.resolve(response);
                }
                else
                    console.log("Orphaned response: " + message.Type);
            }
            else if (message.Type === MessageType.Notification) {
                var notification = JSON.parse(core.Utf8.fromBase64Url(message.Data || ""));
                if (this.onNotification)
                    try {
                        this.onNotification(notification);
                    }
                    catch (e) { }
            }
            else
                console.log("Unknown message type: " + message.Type);
        };
        Channel.prototype.processRequestQueue = function () {
            var _this = this;
            this.pending.forEach(function (req, i, items) {
                if (!req.sent) {
                    _this.webChannel.sendDataTxt(core.Base64Url.fromJSON(req.command));
                    items[i].sent = true;
                }
            });
        };
        Channel.prototype.findRequest = function (response) {
            for (var i = 0; i < this.pending.length; i++) {
                var request = this.pending[i];
                if (request.sent && (request.command.Method === response.Method)) {
                    this.pending.splice(i, 1);
                    return request;
                }
            }
            return null;
        };
        return Channel;
    }());

    /**@internal
     *
     */
    var Command = /** @class */ (function () {
        function Command(method, parameters) {
            this.Method = method;
            this.Parameters = parameters;
        }
        return Command;
    }());
    /**@internal
     *
     */
    var Request = /** @class */ (function () {
        function Request(command) {
            this.command = command;
            this.sent = false;
        }
        return Request;
    }());

    /**@internal
     *
     */
    var Method;
    (function (Method) {
        Method[Method["EnumerateReaders"] = 1] = "EnumerateReaders";
        Method[Method["EnumerateCards"] = 2] = "EnumerateCards";
        Method[Method["GetCardInfo"] = 3] = "GetCardInfo";
        Method[Method["GetCardUID"] = 4] = "GetCardUID";
        Method[Method["GetDPCardAuthData"] = 5] = "GetDPCardAuthData";
        Method[Method["GetDPCardEnrollData"] = 6] = "GetDPCardEnrollData";
        Method[Method["Subscribe"] = 100] = "Subscribe";
        Method[Method["Unsubscribe"] = 101] = "Unsubscribe";
    })(Method || (Method = {}));
    /**@internal
     *
     */
    var NotificationType;
    (function (NotificationType) {
        NotificationType[NotificationType["ReaderConnected"] = 1] = "ReaderConnected";
        NotificationType[NotificationType["ReaderDisconnected"] = 2] = "ReaderDisconnected";
        NotificationType[NotificationType["CardInserted"] = 3] = "CardInserted";
        NotificationType[NotificationType["CardRemoved"] = 4] = "CardRemoved";
    })(NotificationType || (NotificationType = {}));

    /**
     * A card reader API class.
     * An instance of this class allows to subscribe to card reader events and read card data.
     * The card reader API uses DigitalPersona WebSDK to communicate with card reader drivers and hardware.
     */
    var CardsReader = /** @class */ (function (_super) {
        __extends(CardsReader, _super);
        /**
         * Constructs a new card reader API object.
         * @param options - options for the `WebSdk` channel.
         */
        function CardsReader(options) {
            var _this = _super.call(this) || this;
            _this.channel = new Channel("smartcards", options);
            _this.channel.onCommunicationError = _this.onConnectionFailed.bind(_this);
            _this.channel.onNotification = _this.processNotification.bind(_this);
            return _this;
        }
        /**
         * Adds an event handler for the event.
         * This is a multicast subscription, i.e. many handlers can be registered at once.
         *
         * @param event - a name of the event to subscribe, e.g. "CardInserted"
         * @param handler - an event handler.
         * @returns an event handler reference.
         * Store the reference and pass it to the {@link CardsReader.off} to unsubscribe from the event.
         *
         * @example
         * ```
         * class CardComponent
         * {
         *     private reader: CardsReader;
         *
         *     private onCardInserted = (event: CardInserted) => { ... }
         *     private onCardRemoved = (event: CardRemoved) => { ... }
         *     ...
         *
         *     public async $onInit() {
         *         this.reader = new CardsReader();
         *         this.reader.on("CardInserted", this.onCardInserted);
         *         this.reader.on("CardRemoved", this.onCardRemoved);
         *         ...
         *         await this.cardReader.subscribe()
         *     }
         *     public async $onDestroy() {
         *         await this.cardReader.unsubscribe();
         *         this.reader.off("CardInserted", this.onCardInserted);
         *         this.reader.off("CardRemoved", this.onCardRemoved);
         *         ...
         *         // alternatively, call this.reader.off() to unsubscribe from all events at once.
         *         delete this.reader;
         *     }
         * }
         * ```
         */
        CardsReader.prototype.on = function (event, handler) { return this._on(event, handler); };
        /** Deletes an event handler for the event.
         * @param event - a name of the event to subscribe.
         * @param handler - an event handler added with the {@link CardsReader.on} method.
         * @example See example in {@link CardsReader.on}
         */
        CardsReader.prototype.off = function (event, handler) { return this._off(event, handler); };
        /** Lists all connected card readers.
         * @returns a promise to return a list of card reader names.
         */
        CardsReader.prototype.enumerateReaders = function () {
            return this.channel.send(new Request(new Command(Method.EnumerateReaders)))
                .then(function (response) {
                var list = JSON.parse(core.Utf8.fromBase64Url(response.Data || "{}"));
                return JSON.parse(list.Readers || "[]");
            });
        };
        /** Lists all inserted cards.
         * @returns a promise to return a list of card information for connected cards.
         */
        CardsReader.prototype.enumerateCards = function () {
            return this.channel.send(new Request(new Command(Method.EnumerateCards)))
                .then(function (response) {
                var list = JSON.parse(core.Utf8.fromBase64Url(response.Data || "{}"));
                var cards = JSON.parse(list.Cards || "[]");
                return cards.map(function (s) { return JSON.parse(core.Utf16.fromBase64Url(s)); });
            });
        };
        /** Reads card data from a specific card.
         * @param reader - a name of a card reader where the card was presented.
         * @returns a promise to return a card information.
         * The promise can be fulfilled but return `null` if the card has no information.
         * The promise will be rejected if a card is not found or in case of a reading error.
         */
        CardsReader.prototype.getCardInfo = function (reader) {
            return this.channel.send(new Request(new Command(Method.GetCardInfo, core.Base64Url.fromJSON({ Reader: reader }))))
                .then(function (response) {
                var cardInfo = JSON.parse(core.Utf8.fromBase64Url(response.Data || "null"));
                return cardInfo;
            });
        };
        /** Reads a card unique identifier.
         * @param reader - a name of a card reader where the card was presented.
         * @returns a promise to return a card identifier.
         */
        CardsReader.prototype.getCardUid = function (reader) {
            return this.channel.send(new Request(new Command(Method.GetCardUID, core.Base64Url.fromJSON({ Reader: reader }))))
                .then(function (response) {
                var data = core.Base64.fromBase64Url(response.Data || "");
                return data;
            });
        };
        /** Reads card authentication data.
         * @param reader - a name of a card reader where the card was presented.
         * @param pin - an PIN code (for cards requiring a PIN).
         * @returns a promise to return card authentication data.
         * The card data is an opaque encoded string which should be sent to the server as is.
         */
        CardsReader.prototype.getCardAuthData = function (reader, pin) {
            return this.channel.send(new Request(new Command(Method.GetDPCardAuthData, core.Base64Url.fromJSON({ Reader: reader, PIN: pin || "" }))))
                .then(function (response) {
                var data = JSON.parse(core.Utf8.fromBase64Url(response.Data || ""));
                return data;
            });
        };
        /** Reads card enrollment data.
         * @param reader - a name of a card reader where the card was presented.
         * @param pin - an PIN code (for cards requiring a PIN).
         * @returns a promise to return a card enrollment data.
         * The card data is an opaque encoded string which should be sent to the server as is.
         */
        CardsReader.prototype.getCardEnrollData = function (reader, pin) {
            return this.channel.send(new Request(new Command(Method.GetDPCardEnrollData, core.Base64Url.fromJSON({ Reader: reader, PIN: pin || "" }))))
                .then(function (response) {
                var data = JSON.parse(core.Utf8.fromBase64Url(response.Data || ""));
                return data;
            });
        };
        /** Starts listening for card reader events.
         * @param reader - an optional name of a card reader to listen.
         * If no name is provided, the API will start listening all card readers.
         */
        CardsReader.prototype.subscribe = function (reader) {
            return this.channel.send(new Request(new Command(Method.Subscribe, reader ? core.Base64Url.fromJSON({ Reader: reader }) : "")))
                .then();
        };
        /** Stop listening for card reader events.
         * @param reader - an optional name of a card reader to stop listening.
         * If no name is provided, the API will stop listening all card readers.
         */
        CardsReader.prototype.unsubscribe = function (reader) {
            return this.channel.send(new Request(new Command(Method.Unsubscribe, reader ? core.Base64Url.fromJSON({ Reader: reader }) : "")))
                .then();
        };
        /** Converts WebSdk connectivity error to a card API event. */
        CardsReader.prototype.onConnectionFailed = function () {
            this.emit(new CommunicationFailed());
        };
        /** Converts WebSdk notification to card API events. */
        CardsReader.prototype.processNotification = function (notification) {
            switch (notification.Event) {
                case NotificationType.ReaderConnected:
                    return this.emit(new DeviceConnected(notification.Reader));
                case NotificationType.ReaderDisconnected:
                    return this.emit(new DeviceDisconnected(notification.Reader));
                case NotificationType.CardInserted:
                    return this.emit(new CardInserted(notification.Reader, notification.Card));
                case NotificationType.CardRemoved:
                    return this.emit(new CardRemoved(notification.Reader, notification.Card));
                default:
                    console.log("Unknown notification: " + notification.Event);
            }
        };
        return CardsReader;
    }(MultiCastEventSource
    //    implements CommunicationEventSource, DeviceEventSource, CardsEventSource
    ));

    /**
     * Fingerprint device types.
     */
    (function (DeviceUidType) {
        /** The fingerprint device is embedded and cannot be removed. */
        DeviceUidType[DeviceUidType["Persistent"] = 0] = "Persistent";
        /** The fingerprint device can be removed. */
        DeviceUidType[DeviceUidType["Volatile"] = 1] = "Volatile";
    })(exports.DeviceUidType || (exports.DeviceUidType = {}));
    (function (DeviceModality) {
        /** The fingerprint modality is not known. */
        DeviceModality[DeviceModality["Unknown"] = 0] = "Unknown";
        /** Users must swipe a single finger.  */
        DeviceModality[DeviceModality["Swipe"] = 1] = "Swipe";
        /** Users must place a single finger over a scaning area. */
        DeviceModality[DeviceModality["Area"] = 2] = "Area";
        /** Users must place multiple fingers over a scaning area. */
        DeviceModality[DeviceModality["AreaMultifinger"] = 3] = "AreaMultifinger";
    })(exports.DeviceModality || (exports.DeviceModality = {}));
    (function (DeviceTechnology) {
        /** The method of scanning is unknown. */
        DeviceTechnology[DeviceTechnology["Unknown"] = 0] = "Unknown";
        /** The reader uses an optical image of a finger skin. */
        DeviceTechnology[DeviceTechnology["Optical"] = 1] = "Optical";
        /** The reader uses changes of electrical capacitance of a finger skin. */
        DeviceTechnology[DeviceTechnology["Capacitive"] = 2] = "Capacitive";
        /** The reader uses a thermal image of a finger.  */
        DeviceTechnology[DeviceTechnology["Thermal"] = 3] = "Thermal";
        /** The reader uses changes of a pressure under the finger. */
        DeviceTechnology[DeviceTechnology["Pressure"] = 4] = "Pressure";
    })(exports.DeviceTechnology || (exports.DeviceTechnology = {}));

    /**
     * A fingerprint sample format.
     */
    (function (SampleFormat) {
        /** A raw fingerprint image (bitmap). */
        SampleFormat[SampleFormat["Raw"] = 1] = "Raw";
        /** A fingerprint image encoded into an intermediate format. */
        SampleFormat[SampleFormat["Intermediate"] = 2] = "Intermediate";
        /** A compressed fingerprint image (e.q. JPEG2000, WSQ). */
        SampleFormat[SampleFormat["Compressed"] = 3] = "Compressed";
        /** A Portable Network Graphics (PNG) format. */
        SampleFormat[SampleFormat["PngImage"] = 5] = "PngImage";
    })(exports.SampleFormat || (exports.SampleFormat = {}));
    (function (QualityCode) {
        QualityCode[QualityCode["Good"] = 0] = "Good";
        QualityCode[QualityCode["NoImage"] = 1] = "NoImage";
        QualityCode[QualityCode["TooLight"] = 2] = "TooLight";
        QualityCode[QualityCode["TooDark"] = 3] = "TooDark";
        QualityCode[QualityCode["TooNoisy"] = 4] = "TooNoisy";
        QualityCode[QualityCode["LowContrast"] = 5] = "LowContrast";
        QualityCode[QualityCode["NotEnoughFeatures"] = 6] = "NotEnoughFeatures";
        QualityCode[QualityCode["NotCentered"] = 7] = "NotCentered";
        QualityCode[QualityCode["NotAFinger"] = 8] = "NotAFinger";
        QualityCode[QualityCode["TooHigh"] = 9] = "TooHigh";
        QualityCode[QualityCode["TooLow"] = 10] = "TooLow";
        QualityCode[QualityCode["TooLeft"] = 11] = "TooLeft";
        QualityCode[QualityCode["TooRight"] = 12] = "TooRight";
        QualityCode[QualityCode["TooStrange"] = 13] = "TooStrange";
        QualityCode[QualityCode["TooFast"] = 14] = "TooFast";
        QualityCode[QualityCode["TooSkewed"] = 15] = "TooSkewed";
        QualityCode[QualityCode["TooShort"] = 16] = "TooShort";
        QualityCode[QualityCode["TooSlow"] = 17] = "TooSlow";
        QualityCode[QualityCode["ReverseMotion"] = 18] = "ReverseMotion";
        QualityCode[QualityCode["PressureTooHard"] = 19] = "PressureTooHard";
        QualityCode[QualityCode["PressureTooLight"] = 20] = "PressureTooLight";
        QualityCode[QualityCode["WetFinger"] = 21] = "WetFinger";
        QualityCode[QualityCode["FakeFinger"] = 22] = "FakeFinger";
        QualityCode[QualityCode["TooSmall"] = 23] = "TooSmall";
        QualityCode[QualityCode["RotatedTooMuch"] = 24] = "RotatedTooMuch";
    })(exports.QualityCode || (exports.QualityCode = {}));

    /** An event signaling that a new fingerprint sample (or samples) was acquired during a scan. */
    var SamplesAcquired = /** @class */ (function (_super) {
        __extends(SamplesAcquired, _super);
        /** Constructs a new event object.
         * @param deviceUid - a fingerprint reader ID.
         * @param sampleFormat - a fingerprint sample format.
         * @param sampleData - raw sample data received with WebSdk notifiation.
         */
        function SamplesAcquired(deviceUid, sampleFormat, sampleData) {
            var _this = _super.call(this, "SamplesAcquired", deviceUid) || this;
            _this.sampleFormat = sampleFormat;
            _this.samples = JSON.parse(sampleData);
            return _this;
        }
        return SamplesAcquired;
    }(DeviceEvent));
    /** An event reporting a quality of a fingerprint scan. */
    var QualityReported = /** @class */ (function (_super) {
        __extends(QualityReported, _super);
        /** Constructs a new event object.
         * @param deviceUid - a fingerprint reader ID.
         * @param quality - a fingerprint scan quality.
         */
        function QualityReported(deviceUid, quality) {
            var _this = _super.call(this, "QualityReported", deviceUid) || this;
            _this.quality = quality;
            return _this;
        }
        return QualityReported;
    }(DeviceEvent));
    /** An event reporting a fingerprint reader error.  */
    var ErrorOccurred = /** @class */ (function (_super) {
        __extends(ErrorOccurred, _super);
        /** Constructs a new event object.
         * @param deviceUid - a fingeprint reader ID.
         * @param error - an error code.
         */
        function ErrorOccurred(deviceUid, error) {
            var _this = _super.call(this, "ErrorOccurred", deviceUid) || this;
            _this.error = error;
            return _this;
        }
        return ErrorOccurred;
    }(DeviceEvent));
    /** An event signaling that a fingerprint reader is ready and waiting to scan a finger. */
    var AcquisitionStarted = /** @class */ (function (_super) {
        __extends(AcquisitionStarted, _super);
        /** Constructs a new event object.
         * @param deviceUid - a fingeprint reader ID.
         */
        function AcquisitionStarted(deviceUid) {
            return _super.call(this, "AcquisitionStarted", deviceUid) || this;
        }
        return AcquisitionStarted;
    }(DeviceEvent));
    /** An event signaling that a fingerprint reader has stopped waiting for a finger scan. */
    var AcquisitionStopped = /** @class */ (function (_super) {
        __extends(AcquisitionStopped, _super);
        /** Constructs a new event object.
         * @param deviceUid - a fingeprint reader ID.
         */
        function AcquisitionStopped(deviceUid) {
            return _super.call(this, "AcquisitionStopped", deviceUid) || this;
        }
        return AcquisitionStopped;
    }(DeviceEvent));

    /**@internal
     *
     */
    var Method$1;
    (function (Method) {
        Method[Method["EnumerateDevices"] = 1] = "EnumerateDevices";
        Method[Method["GetDeviceInfo"] = 2] = "GetDeviceInfo";
        Method[Method["StartAcquisition"] = 3] = "StartAcquisition";
        Method[Method["StopAcquisition"] = 4] = "StopAcquisition";
    })(Method$1 || (Method$1 = {}));
    /**@internal
     *
     */
    var NotificationType$1;
    (function (NotificationType) {
        NotificationType[NotificationType["Completed"] = 0] = "Completed";
        NotificationType[NotificationType["Error"] = 1] = "Error";
        NotificationType[NotificationType["Disconnected"] = 2] = "Disconnected";
        NotificationType[NotificationType["Connected"] = 3] = "Connected";
        NotificationType[NotificationType["Quality"] = 4] = "Quality";
        NotificationType[NotificationType["Stopped"] = 10] = "Stopped";
        NotificationType[NotificationType["Started"] = 11] = "Started";
    })(NotificationType$1 || (NotificationType$1 = {}));

    /**
     * A fingerprint reader API.
     * An instance of this class allows to subscribe to finerprint reader events and read fingerprint data.
     * The fingerprint reader API uses DigitalPersona WebSDK to communicate with fingerprint reader drivers and hardware.
     */
    var FingerprintReader = /** @class */ (function (_super) {
        __extends(FingerprintReader, _super);
        /**
         * Constructs a new fingerprint reader API object.
         * @param options - options for the `WebSdk` channel.
         */
        function FingerprintReader(options) {
            var _this = _super.call(this) || this;
            _this.options = options;
            _this.channel = new Channel("fingerprints", _this.options);
            _this.channel.onCommunicationError = _this.onConnectionFailed.bind(_this);
            _this.channel.onNotification = _this.processNotification.bind(_this);
            return _this;
        }
        /**
         * Adds an event handler for the event.
         * This is a multicast subscription, i.e. many handlers can be registered at once.
         *
         * @param event - a name of the event to subscribe, e.g. "SampleAcquired"
         * @param handler - an event handler.
         * @returns an event handler reference.
         * Store the reference and pass it to the {@link FingerprintReader.off} to unsubscribe from the event.
         *
         * @example
         * ```
         * class FingerprintComponent
         * {
         *     private reader: FingerprintReader;
         *
         *     private onDeviceConnected = (event: DeviceConnected) => { ... };
         *     private onDeviceDisconnected = (event: DeviceDisconnected) => { ... };
         *     private onSamplesAcquired = (event: SampleAquired) => { ... };
         *     ...
         *
         *     public async $onInit() {
         *         this.reader = new FingerprintReader();
         *         this.reader.on("DeviceConnected", onDeviceConnected);
         *         this.reader.on("DeviceDisconnected", onDeviceDisconnected);
         *         this.reader.on("SamplesAcquired", onSamplesAcquired);
         *         ...
         *         await this.fingerprintReader.startAcquisition(SampleFormat.Intermediate);
         *     }
         *     public async $onDestroy() {
         *         await this.fingerprintReader.stopAcquisition();
         *         this.reader.off("DeviceConnected", onDeviceConnected);
         *         this.reader.off("DeviceDisconnected", onDeviceDisconnected);
         *         this.reader.off("SamplesAcquired", onSamplesAcquired);
         *         ...
         *         // alternatively, call this.reader.off() to unsubscribe from all events at once.
         *         delete this.reader;
         *     }
         * }
         * ```
         */
        FingerprintReader.prototype.on = function (event, handler) { return this._on(event, handler); };
        /** Deletes an event handler for the event.
         * @param event - a name of the event to subscribe.
         * @param handler - an event handler added with the {@link FingerprintReader.on} method.
         */
        FingerprintReader.prototype.off = function (event, handler) { return this._off(event, handler); };
        /** Lists all connected fingerprint readers.
         * @returns a promise to return a list of fingerprint reader names.
         */
        FingerprintReader.prototype.enumerateDevices = function () {
            return this.channel.send(new Request(new Command(Method$1.EnumerateDevices)))
                .then(function (response) {
                if (!response)
                    return [];
                var deviceList = JSON.parse(core.Utf8.fromBase64Url(response.Data || "{}"));
                return JSON.parse(deviceList.DeviceIDs || "[]");
            });
        };
        /** Reads a fingerprint reader device information.
         * @param deviceUid - a fingerprint reader ID.
         * @returns a promise to return a device information.
         * The promise can be fulfilled but return `null` if the reader provides no information.
         * The promise will be rejected if a reader is not found or in case of a reading error.
         */
        FingerprintReader.prototype.getDeviceInfo = function (deviceUid) {
            return this.channel.send(new Request(new Command(Method$1.GetDeviceInfo, core.Base64Url.fromJSON({ DeviceID: deviceUid }))))
                .then(function (response) {
                var deviceInfo = JSON.parse(core.Utf8.fromBase64Url(response.Data || "null"));
                return deviceInfo;
            });
        };
        /** Activate a fingerprint acquisition mode.
         * This call will produce a {@link AcquisitionStarted} event if activation was successful.
         * After that the reader will wait for a finger placed on the reader.
         * When a finger is placed, a {@link QualityReported} event will report a scan quality,
         * and a {@link SamplesAcquired} event will return a scanned sample in case of a successful scan.
         */
        FingerprintReader.prototype.startAcquisition = function (sampleFormat, deviceUid) {
            return this.channel.send(new Request(new Command(Method$1.StartAcquisition, core.Base64Url.fromJSON({
                DeviceID: deviceUid ? deviceUid : "00000000-0000-0000-0000-000000000000",
                SampleType: sampleFormat,
            }))))
                .then();
        };
        /** Deactivates a fingerprint acquisition mode.
         * This call will produce a {@link AcquisitionStopped} event if deactivation was successful.
         * After that the reader will stop waiting for a finger.
         */
        FingerprintReader.prototype.stopAcquisition = function (deviceUid) {
            return this.channel.send(new Request(new Command(Method$1.StopAcquisition, core.Base64Url.fromJSON({
                DeviceID: deviceUid ? deviceUid : "00000000-0000-0000-0000-000000000000",
            }))))
                .then();
        };
        /** Converts WebSdk connectivity error to a fingerprint API event. */
        FingerprintReader.prototype.onConnectionFailed = function () {
            this.emit(new CommunicationFailed());
        };
        /** Converts WebSdk notification to fingerprint API events. */
        FingerprintReader.prototype.processNotification = function (notification) {
            switch (notification.Event) {
                case NotificationType$1.Completed:
                    var completed = JSON.parse(core.Utf8.fromBase64Url(notification.Data || ""));
                    return this.emit(new SamplesAcquired(notification.Device, completed.SampleFormat, completed.Samples));
                case NotificationType$1.Error:
                    var error = JSON.parse(core.Utf8.fromBase64Url(notification.Data || ""));
                    return this.emit(new ErrorOccurred(notification.Device, error.uError));
                case NotificationType$1.Disconnected:
                    return this.emit(new DeviceDisconnected(notification.Device));
                case NotificationType$1.Connected:
                    return this.emit(new DeviceConnected(notification.Device));
                case NotificationType$1.Quality:
                    var quality = JSON.parse(core.Utf8.fromBase64Url(notification.Data || ""));
                    return this.emit(new QualityReported(notification.Device, quality.Quality));
                case NotificationType$1.Stopped:
                    return this.emit(new AcquisitionStopped(notification.Device));
                case NotificationType$1.Started:
                    return this.emit(new AcquisitionStarted(notification.Device));
                default:
                    console.log("Unknown notification: " + notification.Event);
            }
        };
        return FingerprintReader;
    }(MultiCastEventSource
    //    implements FingerprintsEventSource, DeviceEventSource, CommunicationEventSource
    ));

    /**@internal
     *
     */
    var Method$2;
    (function (Method) {
        Method[Method["Init"] = 1] = "Init";
        Method[Method["Continue"] = 2] = "Continue";
        Method[Method["Term"] = 3] = "Term";
        Method[Method["Authenticate"] = 4] = "Authenticate";
    })(Method$2 || (Method$2 = {}));
    /**@internal
     *
     */
    var MessageType$1;
    (function (MessageType) {
        MessageType[MessageType["Response"] = 0] = "Response";
        MessageType[MessageType["Notification"] = 1] = "Notification";
    })(MessageType$1 || (MessageType$1 = {}));

    /**
     * Integrated Windows Authentication API.
     * An instance of this class allows internet browsers to authenticate in DigitalPersona servers
     * using Integrated Windows Authentication.
     * The IWA API uses DigitalPersona WebSDK to communicate with Windwows operating system and extract
     * Windows account data for authentication.
     */
    var WindowsAuthClient = /** @class */ (function (_super) {
        __extends(WindowsAuthClient, _super);
        /**
         * Constructs a new IWA API object.
         * @param options - options for the `WebSdk` channel.
         */
        function WindowsAuthClient(options) {
            var _this = _super.call(this) || this;
            _this.channel = new Channel("wia", options);
            _this.channel.onCommunicationError = _this.onConnectionFailed.bind(_this);
            return _this;
        }
        /**
         * Adds an event handler for the event.
         * This is a multicast subscription, i.e. many handlers can be registered at once.
         *
         * @param event - a name of the event to subscribe, e.g. "CommunicationFailed"
         * @param handler - an event handler.
         * @returns an event handler reference.
         * Store the reference and pass it to the {@link WindowsAuthClient.off} to unsubscribe from the event.
         *
         * @example
         * ```
         * class IntegratedWindowsAuthComponent
         * {
         *     private client: WindowsAuthClient;
         *
         *     private onCommunicationFailed = (event: CommunicationFailed) => { ... }
         *
         *     public $onInit() {
         *         this.client = new WindowsAuthClient();
         *         this.client.on("CommunicationFailed", this.onCommunicationFailed);
         *     }
         *     public $onDestroy() {
         *         this.client.off("CommunicationFailed", this.onCommunicationFailed);
         *         // alternatively, call this.reader.off() to unsubscribe from all events at once.
         *         delete this.client;
         *     }
         * }
         * ```
         */
        WindowsAuthClient.prototype.on = function (event, handler) { return this._on(event, handler); };
        /** Deletes an event handler for the event.
         * @param event - a name of the event to subscribe.
         * @param handler - an event handler added with the {@link WindowsAuthClient.on} method.
         */
        WindowsAuthClient.prototype.off = function (event, handler) { return this._off(event, handler); };
        /** Used internally. Do not call this method. */
        WindowsAuthClient.prototype.init = function () {
            return this.channel.send(new Request(new Command(Method$2.Init)), 3000)
                .then(function (response) {
                var data = JSON.parse(response.Data || "{}");
                return { handle: data.Handle, data: data.Data };
            });
        };
        /** Used internally. Do not call this method. */
        WindowsAuthClient.prototype.continue = function (handle, data) {
            return this.channel.send(new Request(new Command(Method$2.Continue, JSON.stringify({ Handle: handle, Data: data }))))
                .then(function (response) {
                var d = JSON.parse(response.Data || "{}");
                return d.Data;
            });
        };
        /** Used internally. Do not call this method. */
        WindowsAuthClient.prototype.term = function (handle) {
            return this.channel.send(new Request(new Command(Method$2.Term, JSON.stringify({ Handle: handle }))))
                .then();
        };
        /** Converts WebSdk connectivity error to an IWA API event. */
        WindowsAuthClient.prototype.onConnectionFailed = function () {
            this.emit(new CommunicationFailed());
        };
        return WindowsAuthClient;
    }(MultiCastEventSource));

    exports.AcquisitionStarted = AcquisitionStarted;
    exports.AcquisitionStopped = AcquisitionStopped;
    exports.CardInserted = CardInserted;
    exports.CardRemoved = CardRemoved;
    exports.CardsReader = CardsReader;
    exports.CommunicationFailed = CommunicationFailed;
    exports.DeviceConnected = DeviceConnected;
    exports.DeviceDisconnected = DeviceDisconnected;
    exports.DeviceEvent = DeviceEvent;
    exports.ErrorOccurred = ErrorOccurred;
    exports.Event = Event;
    exports.FingerprintReader = FingerprintReader;
    exports.QualityReported = QualityReported;
    exports.SamplesAcquired = SamplesAcquired;
    exports.WindowsAuthClient = WindowsAuthClient;

    Object.defineProperty(exports, '__esModule', { value: true });

}));
//# sourceMappingURL=index.umd.js.map


/***/ })

}]);