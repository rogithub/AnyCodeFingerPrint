
$(() => {
    console.log("fp.js rodrigo's file");
});
